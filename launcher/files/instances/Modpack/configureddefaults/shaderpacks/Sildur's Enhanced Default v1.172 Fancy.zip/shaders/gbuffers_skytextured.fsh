#version 120
/* DRAWBUFFERS:02 */ //0=gcolor, 2=gnormal for normals
/*
Sildur's Enhanced Default:
https://www.patreon.com/Sildur
https://sildurs-shaders.github.io/
https://twitter.com/Sildurs_shaders
https://www.curseforge.com/minecraft/customization/sildurs-enhanced-default

Permissions:
You are not allowed to edit, copy code or share my shaderpack under a different name or claim it as yours.
*/

varying vec2 texcoord;
varying vec4 color;
uniform sampler2D texture;

void main() {

	gl_FragData[0] = texture2D(texture, texcoord.xy)*color;
    gl_FragData[1] = vec4(0.0); //fills normal buffer with 0.0, improves overall performance
}
